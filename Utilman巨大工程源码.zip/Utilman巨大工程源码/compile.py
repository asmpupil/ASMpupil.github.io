import PyInstaller.__main__

PyInstaller.__main__.run([
  'Utilman (1).py',    # 您的脚本文件名
  '--onefile',
  '--windowed',
  '--name=SystemToolsLauncher',
  '--uac-admin',
  '--icon=NONE',        # 不使用图标
  '--clean',
  '--noconfirm'
])
