import tkinter as tk
import subprocess
import sys
import os

def open_utilman():
    """打开辅助功能工具"""
    subprocess.Popen([r"C:\Windows\System32\Utilman2.exe"], creationflags=subprocess.CREATE_NO_WINDOW)

def open_cmd():
    """打开cmd"""
    subprocess.Popen([r"C:\Windows\System32\cmdc++.exe"], creationflags=subprocess.CREATE_NO_WINDOW)

def open_taskmgr():
    """打开任务管理器"""
    subprocess.Popen([r"C:\Windows\System32\Taskmgr.exe"], creationflags=subprocess.CREATE_NO_WINDOW)

def open_notepad():
    """打开记事本"""
    subprocess.Popen([r"C:\Windows\notepad.exe"], creationflags=subprocess.CREATE_NO_WINDOW)

def open_regedit():
    """打开注册表编辑器"""
    subprocess.Popen([r"C:\Windows\regedit.exe"], creationflags=subprocess.CREATE_NO_WINDOW)

# 创建主窗口
root = tk.Tk()
root.title("系统工具快捷启动器")
root.geometry("400x550")
root.resizable(False, False)  # 固定窗口大小

# 使用更美观的界面元素
tk.Label(root, text="系统工具快捷启动器", 
         font=("Microsoft YaHei", 16, "bold"), 
         fg="#2c3e50", pady=10).pack()
frame = tk.Frame(root, padx=20, pady=10)
frame.pack(fill=tk.BOTH, expand=True)

# 按钮数据和对应功能
buttons = [
    ("打开辅助功能", open_utilman),
    ("打开cmd", open_cmd),
    ("打开任务管理器", open_taskmgr),
    ("打开记事本", open_notepad),
    ("打开注册表编辑器", open_regedit)
]

# 创建按钮
for text, command in buttons:
    btn = tk.Button(
        frame, text=text, command=command,
        width=20, height=2, 
        font=("Microsoft YaHei", 10),
        bg="#3498db", fg="white", activebackground="#2980b9",
        relief=tk.FLAT
    )
    btn.pack(pady=7, fill=tk.X)

# 添加退出按钮
tk.Button(root, text="退出程序", command=sys.exit, 
          width=10, font=("Microsoft YaHei", 9),
          bg="#e74c3c", fg="white", activebackground="#c0392b",
          pady=5).pack(pady=15)

root.mainloop()
