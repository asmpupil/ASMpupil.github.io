#include <iostream>
using namespace std;
int main(){
system("start cmd"); 
return 0;
}
